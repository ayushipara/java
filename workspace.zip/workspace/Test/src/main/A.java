package main;

public interface A {

	default void testDefault() {
		System.out.println("interface A in test default");
		
	}
}
