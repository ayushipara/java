package main;

public abstract class EmployeeAbstract {

	abstract void compute();

}
