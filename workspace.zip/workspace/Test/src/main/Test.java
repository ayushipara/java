package main;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.PriorityQueue;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Test {
	
	public static void main(String args[]) {
		/*
		 * long a =1; Long b = 1l; Long c = 1l;
		 * 
		 * System.out.println(a==b); System.out.println(a==c); System.out.println(b==c);
		 * System.out.println(b.equals(c));
		 */
		
		
		quickSorting();
		
		binarySearch();
		
		priority();
		
		reverserInt();
		
		
		getPowerIndex();
		
		
		Predicate<String> predicate = q -> q.toLowerCase().startsWith("s");
		
		
		
		
		List<String> cities = new ArrayList<String>();
		cities.add("Mumbai");
		cities.add("Jaipur");
		cities.add("Raipur");
		cities.stream().filter(predicate).forEach(System.out::println);
		Consumer<List<String>> addingPlural = p ->{
			int count=0;
			for(String sp : p) {
				p.set(count++,sp.concat("s"));
			}
		};
		Consumer<List<String>> dispList = p -> p.stream().forEach(a -> System.out.println(a));
		
//		Supplier<Double> doubleValue = () -> (23.1);
//		
//		System.out.println(doubleValue.get());
		
		
//		System.out.println(cities);
//		addingPlural.accept(cities);
		dispList.accept(cities);
//		listOfCities.accept(cities);
		HashMap<String,String> map = new HashMap<>();
		
//		map.put(null, "sanjay");
//		System.out.println(map.get(null));
		
//		Consumer<List<String> > modify = list ->
//        {
//            for (int i = 0; i < list.size(); i++)
//                list.set(i,list.get(i)+"s");
//        };
//        
//        Consumer<List<String> >
//        dispList = list -> list.stream().forEach(a -> System.out.print(a + " "));
//        
//        List<String> list = new ArrayList<String>();
//        list.add("Mumbai");
//        list.add("Jaipur");
//        list.add("Raipur");
//        
//        modify.accept(list);
//        
//        // Implement dispList using accept()
//        dispList.accept(list);
		
		Aa a = new Aa();
		a.testDefault();
	}

	private static void quickSorting() {
		int[] arry = {4,8,2,3,1,7,5,6};
		quickSorting(arry,0,arry.length-1);
		System.out.println(arry);
		System.out.println("counter :: "+counter);
	}
	static int counter=0;
	private static void quickSorting(int[] arry,int first, int last) {
		if(first<last) {
			int pivot = partition(arry,first,last);
			quickSorting(arry, first, pivot-1);
			quickSorting(arry, pivot+1, last);
		}
	}

	private static int partition(int[] arry, int first, int last) {
		int pivot = arry[last];
		int i = first - 1;
		for(int j=first;j<last;j++) {
			counter++;
			if(arry[j]<=pivot) {
				i++;
				int swap = arry[i];
				arry[i] = arry[j];
				arry[j] = swap;
			}
		}
		int swap = arry[i+1];
		arry[i+1] = arry[last];
		arry[last] = swap;
		return i+1;
	}

	private static void binarySearch() {
		int intArry[] = {1,2,3,4,5,6,7,8};
		int size = 8;
		int input = 7;
		System.out.println("element found:: "+checkIndex(intArry,0,size,input));
	}
	
	private static int checkIndex(int[] arry, int start,int end, int input) {
		int halfIndex = (start+end) /2;
		
		if(input == arry[halfIndex]) {
			return halfIndex;
		}else if(input < arry[halfIndex]) {
			end = halfIndex - 1;
			return checkIndex(arry,start,end,input);
		}else {
			start = halfIndex + 1;
			return checkIndex(arry,start,end,input);
		}
	}
	

	private static void getPowerIndex() {
		List<Integer> arr = new ArrayList<>();
		arr.add(9);
		arr.add(5);
		arr.add(6);
		arr.add(10);
		arr.add(9);
		arr.add(10);
		arr.add(9);
		arr.add(9);
		arr.add(7);
		long max = 0;
		int index = -1;
		
		BigDecimal 	qw = new BigDecimal(Math.pow(10, 9));
		BigDecimal 	tr = new BigDecimal(Math.pow(9, 10));
		
		
		
		
		for(int i=0;i<arr.size();i++) {
			long currVal = 0;
			if(i<arr.size()-1) {
				currVal  = (long) (Math.pow(arr.get(i), arr.get(i+1))) % 1000000007;
				System.out.println(i+"----> "+ currVal);
				if(max<currVal) {
					max = currVal;
					index = i;
				}
			}
		}
		
		System.out.println(index);
		
			
		
	}

	private static void reverserInt() {
		List<Integer> arr = new ArrayList<>();
		
		Collections.reverse(arr);
		
	}

	private static void priority() {
		PriorityQueue toDo = new PriorityQueue();
		toDo.add("dishes");
		toDo.add("laundry");
		toDo.add("bills");
		toDo.offer("bills");
		
		System.out.print(" "+ toDo.size() + " " + toDo.poll());
		System.out.print(" "+ toDo.peek() + " " + toDo.poll());
		System.out.print(" "+ toDo.poll() + " " + toDo.poll());
		
	}
}
