package main;

public class Aa implements A{

//	public void testDefault() {
//		System.out.println("Class Aa in testdefault method");
//	}
}
