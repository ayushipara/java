package main;

import java.util.HashMap;
import java.util.Map;

public class Practice {

	public static void main(String[] args) {
		HashMap<String,String> map = new HashMap<>();
		for(Map.Entry<String, String> entry: map.entrySet()) {
		
		}
		
		int a =2;
		float b = 2;
		long c =2;
		float d = a+b+c;
		System.out.println(d);
		
	}
}
