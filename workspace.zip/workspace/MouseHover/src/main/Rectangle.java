package main;

public class Rectangle extends Shape {
	
	public void draw() {
		System.out.println("Drawing shape");
	}
}
