package main;

public class Square {
	
	public void draw() {
		System.out.println("Drawing a square");
	}
}
