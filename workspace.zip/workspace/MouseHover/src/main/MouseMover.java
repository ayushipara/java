package main;

import java.awt.Robot;
import java.util.Date;
import java.util.Random;

public class MouseMover {

	public static final int FIVE_SECONDS=5000;
	public static final int MAX_Y = 400;
	public static final int MAX_X = 400;

	public static void main(String[] args) throws Exception {
		
		//		long start = System.currentTimeMillis();
		//		Thread1 abc = new Thread1();
		//		abc.start();
		//		Thread2 abc2 = new Thread2();
		//		Thread t2 = new Thread(abc2);
		//
		//		t2.start();
		//		long end = System.currentTimeMillis();
		//		
		//		System.out.println("------------------"+ (end-start));
		//		
		//		
		//		System.out.println("1---------"+abc.getName());
		//		System.out.println("2-----------"+t2.getName());
		//		System.out.println("3-------------"+Thread.currentThread().getName());
				
		
		
//		Outer outer = new Outer();
//		outer.setOutterX(3);
//		outer.show();
//		Outer.Inner inner = new Outer.Inner();
//		inner.show();
		
		
		/*
		 * testing volatile modifier
		 */
//		Test test = new Test();
//		Thread t1 = new Thread(test);
//		Thread t2 = new Thread(test);
//		t1.start();
//		t2.start();
		
		
//		String name =" hello buddy";
//		String name1 = "hello Buddy";
//		System.out.println(name.equalsIgnoreCase(name1));
//		System.out.println(name.hashCode());
//		System.out.println(name1.hashCode());
		
		
		
//		Date date = new Date();
//		
//		String dateString = String.format("%td %<tB %<ty %<tk:%<tM:%<tS", date);
//		System.out.println(dateString);
		
				Robot robot = new Robot();
				Random random = new Random();
				while(true) {
						robot.mouseMove(random.nextInt(MAX_X), random.nextInt(MAX_Y));
						Thread.sleep(FIVE_SECONDS);
				}	
				
			}

//DATEFORMAT DF = NEW SIMPLEDATEFORMAT("DD/MM/YYYY HH:MM:SS:SSS");
//		SYSTEM.OUT.PRINTLN("---------------------------"+DF.FORMAT(NEW JAVA.UTIL.DATE()));
//		EXECUTORSERVICE ES = EXECUTORS.NEWFIXEDTHREADPOOL(10);
//		THREAD1 THR = NEW THREAD1();
//		FOR(INT I=0;I<10;I++) {
//			SYSTEM.OUT.PRINTLN("THREAD NAME"+ THREAD.CURRENTTHREAD().GETID());
////			THR.PROCESS();
//			ES.EXECUTE(NEW THREAD1());
//		}
//		ES.SHUTDOWN();
//		ES.AWAITTERMINATION(6, TIMEUNIT.MINUTES);
//		SYSTEM.OUT.PRINTLN("---------------------------"+DF.FORMAT(NEW JAVA.UTIL.DATE()));
//	}
}


class Outer{ }


class Thread1 extends Thread {

	@Override
	public void run() {
		process();

	}
	public void process() {
//		IntStream.range(0, 50).forEach(System.out::println);
//		System.out.println("-------------print");


	}
}
class Thread2 implements Runnable {

	@Override
	public void run() {
		process();

	}
	private void process() {
//		IntStream.range(51, 100).forEach(System.out::println);
		System.out.println("-------------print");

	}
}


class Test implements Runnable{
	
	 volatile int sharedVariable = 10;
	Random random =  new Random();

	@Override
	public void run() {
		while(true) {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			process();
		}


	}

	private void process() {
		System.out.println("previous shared variable is :: "+sharedVariable+" thread ::"+Thread.currentThread());
		sharedVariable = random.nextInt();
		System.out.println("after shared variable is :: "+sharedVariable+" thread ::"+Thread.currentThread());
	}
	
}
