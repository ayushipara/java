package main;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Practise{
	
	void display(Object p) {
		System.out.println("Practise");
	}
	
	void display(String str) {
		System.out.println("String");
	}
	public static void main(String[] args) {
			
		
		Animal dg = new Dog();
		
		System.out.println(dg.move());
		
		double d = 10.0/ -0;
		if(d == Double.POSITIVE_INFINITY)
			System.out.println("Positive");
		else
			System.out.println("negative");
		
//		rearanage();
		
		shiftArray();
		
		
		Function<String,String> predicate = x-> x.toUpperCase();
		
		
//		new Practise().display(null);
		
		List<Customer> customerList = new ArrayList<>();
//		input.add("sanjay");
//		input.add("pramod");
//		input.add("ashish");
//		input.add("santosh");
		
		
		String firstInput = "java,C++,html";
		String secondInput = "java,c++";
		String[] firstArray = firstInput.split(",");
		for(String f : firstArray) {
			if(f.contains(secondInput)) {
				System.out.println("yes");
			}else {
				System.out.println("no");
				
			}
			
		}
		
		
		
		
		String a = "sanjay";
		String b = "sanjay";
		System.out.println(a.hashCode());
		System.out.println(b.hashCode());
		
		a = a.concat("s");
		
		
		Customer cust  = new Customer();
		cust.setId(1);
		cust.setName("sanjay");
		customerList.add(cust);
		System.out.println(cust.hashCode());
		cust = new Customer();
		cust.setId(2);
		cust.setName("priya");
		System.out.println(cust.hashCode());
		customerList.add(cust);
		
		
		
		//remove the customer as per input
		int userInputId = 2;
		Customer cust1 = null;
		for(Customer customer:customerList) {
			if(customer.getId()==userInputId) {
				customer.setName("arjun");
				break;
			}
		}
		
		if(cust1!=null)
			customerList.remove(cust1);
		
		customerList.stream().forEach(System.out::println);
//		
//		customerList.remove(0);
		System.out.println(customerList.size());
//		input.stream().map(n->n.toUpperCase()).filter(n->!n.startsWith("S")).forEach(System.out::print);
		
		
		
//		List<Double> list = new ArrayList<>();
//		list.add(23.3);
//		
//		double[] sd = new double[21];
//		
//		printMaxNumber();
//		printMaxNumber();
		
//		LIST<STRING> STRINGLIST = LIST.OF("CARLO","JAMES","VICTOR");
//		STRING[] STRINGARRAY = {"ABC","XYZ"};
//		INT C =2;
//		LIST<NUMBER> NUMBERLIST = LIST.OF(1,5,8,2,5,3);
//		printData(numberList, stringArray, c);
//		printData(numberList);
//		getCompare(2,4,6);
		
		
//		List<Rectangle> rectangleLists = new ArrayList<>();
//		rectangleLists.add(new Rectangle());
//		drawShapes(rectangleLists);
		
//		List<Circle> circleLists = new ArrayList<>();
//		circleLists.add(new Circle());
//		drawShapes(circleLists);
		
		
		
//		List<Square> squareLists = new ArrayList<>();
//		squareLists.add(new Square());
//		drawShapes(squareLists);
		
		
		
		
//		stringFormat();
		
//		printString(stringList);
//		printNumber(numberList);
		
		
//		Animal a = new Animal();
//		Animal b = new Dog();
//		Dog d = new Dog();
		
		
		
	}
	
	private static void shiftArray() {
		int[] n = {1,2,3,4,5,6,7};
		
		print(n,3);
		
	}

	private static void print(int[] n, int rotateNum) {
		
		int[] newArray = new int[n.length];
		for(int i=0;i<n.length;i++) {
			int num = i-rotateNum + n.length;
			num = num>=7 ? num -7 : num;
			newArray[num] = n[i];
		}
		System.out.println(Arrays.asList(newArray).stream().map(i->String.valueOf(i)).collect(Collectors.joining(",")));
		
	}

	private static void rearanage() {
		String input = "abac";
		String input2 = "bcac";
		
		if(input.length()!= input2.length()) {
			System.out.println("NO");
		}
		
		Map<Character,Integer> inputMap = loop(input);
		Map<Character,Integer> input2Map = loop(input2);
		
		for(Map.Entry<Character, Integer> entry: inputMap.entrySet()){
			if(entry.getValue() == input2Map.get(entry.getKey()).intValue()) {
				System.out.println("Yes");
			}else {
				System.out.println("NO");
				break;
			}
		}
	}

	private static Map<Character, Integer> loop(String input) {
		Map<Character,Integer> inputMap = new HashMap<>();
		for(int i=0;i<input.length();i++) {
			if(inputMap.containsKey(input.charAt(i)))
				inputMap.put(input.charAt(i), inputMap.get(input.charAt(i)).intValue()+1);
			else
				inputMap.put(input.charAt(i), 0);
		}
		return inputMap;
	}

	private static void drawShapes(List<? extends Shape> lists) {
		for(Shape s : lists) {
			s.draw();
		}
		
	}
	
	
	
	private static void stringFormat() {
		String name = "sanjay";
		String lastName = "barai";
		String msg = "Hey I am %s %s";
		System.out.println(String.format(msg, name, lastName));
		
		
		
		
	}


	private static void printNumber(List<Integer> numberList) {
		System.out.println(numberList);
	}


	private static void printString(List<String> stringList) {
		System.out.println(stringList);

	}


	public static <T,E> void printData(List<T> elements, E[] elementArray,T s) {
//		E result = elements.get(0);
		System.out.println(elements);
		
	}
	
	public static <T extends Comparable<T>> void getCompare(T a, T b, T c) {
		
		
	}

	private static void printMaxNumber(double ...number) {
		if(number.length==0)
			System.out.println("there is no data");
		else
			System.out.println("there is data");
		
		
	}

	private static void addingList(int list) {
		list=12;
	}

	private static void swapFunction(int a, int b, int d) {
		System.out.println("Before swapping(Inside), a = " + a
				+ " b = " + b);
		// Swap n1 with n2
		int c = a;
		a = b;
		b = c;
		System.out.println("After swapping(Inside), a = " + a
				+ " b = " + b);
		d = a*b;
	}
	
	
	private static void Exception() {
		try {
			
		} catch (ArithmeticException e) {
			// TODO: handle exception
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}

class Customer{
	private int id;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}

class Animal{
	
	public String move() {
		System.out.println("Animal can move");
		return "str";
	}
}

class Dog extends Animal{
	
	public String dogMove() {
		System.out.println("dogs can walk and run");
		return "";
	}
	
}
