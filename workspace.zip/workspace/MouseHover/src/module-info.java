module MouseHover {
	requires java.desktop;
}