package com.myCompany.person;

import com.myCompany.console.ConsolePrint;

public class Person2 extends Thread{

	ConsolePrint cp;

	public Person2(ConsolePrint cp){
		this.cp = cp;
	}

	@Override
	public void run() {
		while(true) {
			this.cp.person2();
		}
	}
}
