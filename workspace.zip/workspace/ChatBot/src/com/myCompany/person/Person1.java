package com.myCompany.person;

import com.myCompany.console.ConsolePrint;

public class Person1 extends Thread {

	ConsolePrint cp;
	
	public Person1(ConsolePrint cp){
		this.cp = cp;
	}
	
	@Override
	public void run() {
		while(true) {
			this.cp.person1();
		}
	}
}
