package com.myCompany.main;

import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.myCompany.console.ConsolePrint;
import com.myCompany.person.Person1;
import com.myCompany.person.Person2;

public class MyChatBot {

//	public static void main(String[] args) {
//		/*
//		 * Scanner sc = new Scanner(System.in);
//		 * System.out.println("Welcome to chat bot");
//		 * System.out.println("Enter first person name"); String name1 = sc.nextLine();
//		 * System.out.println("Enter second person name"); String name2 = sc.nextLine();
//		 * 
//		 * ConsolePrint cp = new ConsolePrint(name1,name2); Person1 p1 = new
//		 * Person1(cp); Person2 p2 = new Person2(cp);
//		 */
//		//		p2.start();
//		//		p1.start();
//		
//	} 
//}

//public class VolatileTest {
	private static int MY_INT = 0;
	public static void main(String[] args) {
		new ChangeListener().start();
		new ChangeMaker().start();
	}
	static class ChangeListener extends Thread {
		@Override
		public void run() {
			int local_value = MY_INT;
			while ( local_value < 5){
				if( local_value!= MY_INT){
					System.out.println("Got Change for MY_INT : "+ MY_INT);
					local_value= MY_INT;
				}
			}
		}
	}
	static class ChangeMaker extends Thread{
		@Override
		public void run() {
			int local_value = MY_INT;
			while (MY_INT <5){
				System.out.println("Incrementing MY_INT to "+(local_value+1));
				MY_INT = ++local_value;
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) { e.printStackTrace(); }
			}
		}
	}
}
