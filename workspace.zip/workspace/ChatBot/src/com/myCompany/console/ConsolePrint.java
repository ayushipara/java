package com.myCompany.console;

import java.util.Scanner;

public class ConsolePrint {

	public ConsolePrint(String name1, String name2) {
		this.name1 = name1;
		this.name2 = name2;
	}
	
	private String name1;
	private String name2;	
	private Scanner sc = new Scanner(System.in);
	boolean firstPerson = true;
	private String msg;
	int n = 1;
	//firstPerson = true : chance of person1;
	//firstPerson = false : chance of person2;

	synchronized public void person1() {

		if(n==1) {
			System.out.println(name1+ " is typing...");
			msg = sc.nextLine();	
			n++;
		}
		
		if(!firstPerson) {
			try {
//				System.out.println(name1+ " is going to wait");
				wait();
				System.out.println(name2+ " : " + msg);
				System.out.println(name1+ " is typing...");
				msg = sc.nextLine();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		notify();
		firstPerson = false;
	}

	synchronized public void person2() {

		if(firstPerson) {
			try {
//				System.out.println(name2+ " is going to wait");
				wait();
				System.out.println(name1+ " : " + msg);
				System.out.println(name2+ " is typing...");
				msg = sc.nextLine();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		notify();
		firstPerson = true;
	}



}
