package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class Lie implements CommandLineRunner {

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Lie is executing");
		throw new Exception("Does this works");
	}

}
