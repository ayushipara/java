package com.example.demo.service;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

@Service
public class DemoService {

	public String process() {
		return  new JSONObject().put("name", "Sanjay")
				   .put("city", "Mumbai")
				   .put("lastName", "Barai").toString();
	}
}
