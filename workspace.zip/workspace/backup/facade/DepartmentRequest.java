package com.dailycodebuffer.user.facade;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.dailycodebuffer.user.VO.Department;

 
@FeignClient(name = "DEPARTMENT-SERVICE")
@RibbonClient(name = "DEPARTMENT-SERVICE")
public interface DepartmentRequest {
	
	@GetMapping("/departments/{id}")
	public Department getDepartment(@PathVariable ("id") Long departmentId);

}
