package com.dailycodebuffer.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dailycodebuffer.user.VO.Department;
import com.dailycodebuffer.user.VO.ResponseTemplateVO;
import com.dailycodebuffer.user.entity.User;
import com.dailycodebuffer.user.facade.DepartmentRequest;
import com.dailycodebuffer.user.respository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserService {

	@Autowired
	private UserRepository userResp;
	
	@Autowired
	private DepartmentRequest departmentRequest;

	public User saveUser(User user) {
		log.info("inside user save method in user service class");
		return userResp.save(user);
	}
	
	
	public ResponseTemplateVO getUserWithDepartment(Long userId) {
		log.info("inside get user method in user service class");
		ResponseTemplateVO vo = new ResponseTemplateVO();
		User user = userResp.findByUserId(userId);
		
		log.info("calling department rest url in user service class");
		
		
//		Department department = 
//				restTemplate.getForObject("https://DEPARTMENT-SERVICE/departments/"+user.getDepartmentId(), Department.class);
		
		Department department = departmentRequest.getDepartment(user.getDepartmentId());
		vo.setUser(user);
		vo.setDepartment(department);
		
		return vo;
	}
}
