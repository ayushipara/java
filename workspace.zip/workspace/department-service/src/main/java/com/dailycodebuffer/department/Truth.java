package com.dailycodebuffer.department;

import org.springframework.boot.CommandLineRunner;

public class Truth implements CommandLineRunner {

	@Override
	public void run(String... args) throws Exception {
		System.out.println("True is executing");
		
	}

}
