package com.dailycodebuffer.department;

import org.springframework.boot.CommandLineRunner;

public class Lie implements CommandLineRunner {

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Lie is executing");
		throw new Exception("Does this works");
	}

}
