package tech.getarrays.employeemanager;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@SpringBootApplication
public class EmployeemanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeemanagerApplication.class, args);
	}
	
	//cors configuration
	@Bean
	public CorsFilter corsFilter() {
		CorsConfiguration corsConfiguration = new CorsConfiguration();
		corsConfiguration.setAllowCredentials(true);
		corsConfiguration.setAllowedOrigins(List.of("http://localhost:4200"));
		corsConfiguration.setAllowedHeaders(List.of("Origin","Access-Control-Allow-Origin","Content-Type","Accept","Authorization",
											"Origin, Accept","X-Requested-With","Access-Control-Requested-Method","Access-Control-Requested-Method"));
		corsConfiguration.setExposedHeaders(Arrays.asList("Orign","Content-Type","Accept","Authorization",
									"Access-Control-Allow-Credentials","Access-Control-Allow-Origin"));
		corsConfiguration.setAllowedMethods(List.of("GET","POST","PUT","DELETE","OPTIONS"));
		UrlBasedCorsConfigurationSource urlBasedCorsConfSource=new UrlBasedCorsConfigurationSource();
		urlBasedCorsConfSource.registerCorsConfiguration("/**", corsConfiguration);
		return new CorsFilter(urlBasedCorsConfSource);
	}
}
