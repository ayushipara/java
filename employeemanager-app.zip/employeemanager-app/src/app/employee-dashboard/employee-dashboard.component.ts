import { Employee } from './../employee.model';
import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { HttpErrorResponse } from '@angular/common/http';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.scss']
})
export class EmployeeDashboardComponent implements OnInit {

  public employees !: Employee[];
  showAdd : boolean = false;
  showUpdate : boolean = false;
  public editEmployee?: Employee;

  constructor(private employeeService: EmployeeService){}

  public getEmployee(){
      this.employeeService.getEmployees().subscribe({
        next: (response:Employee[])=>{
          this.employees = response;
        },
        error:(e:HttpErrorResponse)=>{
          alert(e.message);
        },
        complete:()=>{}
      }
      );
  }

  openModal(employee:any,mode:string){
    const div = document.getElementById("main-container");
    const button = document.createElement("button");
    button.style.display='none';
    button.type="button";
    button.setAttribute('data-toggle','modal');
    button.setAttribute('data-target','#addModal');
    div?.appendChild(button);
    if(mode === 'add'){
      this.editEmployee=<Employee>{};
      this.showAdd = true;
      this.showUpdate = false;
    }
    if(mode === 'edit'){
      this.editEmployee = employee;
      this.showUpdate = true;
      this.showAdd = false;
    }

    button.click();
  }

  deleteEmployee(employeeId:number){
    const x = confirm("Are you want to remove the employee?")
    if(x){
      this.employeeService.deleteEmployee(employeeId).subscribe({
        next: ()=>{ alert("Employee successfully removed.")},
        error: (e:HttpErrorResponse)=>{
          alert(e.message);
        },
        complete:()=>{
          this.getEmployee();
        }
        
      })
    }

  }

  ngOnInit(): void {
    this.getEmployee();
  }

  postEmployeeDetail(employeeData:NgForm){
    this.employeeService.postEmployee(employeeData.value).subscribe({
      next : (response:Employee)=>{
        this.getEmployee();
        document.getElementById('cancel')?.click();
        employeeData.reset();
      },
      error: (e:HttpErrorResponse)=>{
        console.log(e.message);
      },
      complete: ()=>{}
    });

  }

  updateEmployeeDetail(updateData:any){
    this.employeeService.updateEmployee(updateData.value).subscribe({
      next : (response:Employee)=>{
        this.getEmployee();
        document.getElementById('cancel')?.click();
      },
      error: (e:HttpErrorResponse)=>{
        console.log(e.message);
      },
      complete: ()=>{}
    });

  }

  public searchEmployee(key:string){
    console.log('prints '+key)
    if(!key){
      this.getEmployee();
    }
    else{
    const results: Employee[]=[];
    for (const emp of this.employees) {
      if (emp.name.toLowerCase().indexOf(key.toLowerCase())!==-1) {
          results.push(emp);
      }
    }

    this.employees=results;
  }
  }

}
