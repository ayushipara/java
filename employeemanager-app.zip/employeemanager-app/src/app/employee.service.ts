import { Employee } from './employee.model';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { map } from "rxjs/operators";
import {Observable} from "rxjs";
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private apiServiceUrl=environment.apiBaseUrl+"/employee";

  constructor(private http: HttpClient) { }

  getEmployees():Observable<Employee[]>{
      return this.http.get<Employee[]>(this.apiServiceUrl)
                      .pipe(map((res:Employee[])=>{
                        return res;
                      }))
  }

  postEmployee(employee:Employee){
    return this.http.post<Employee>(this.apiServiceUrl,employee)
    .pipe(map((res:Employee)=>{
      return res;
    }))
  }

  updateEmployee(employee:Employee){
    return this.http.put<Employee>(this.apiServiceUrl,employee)
    .pipe(map((res:Employee)=>{
      return res;
    }))
  }

  deleteEmployee(employeeId:number){
    return this.http.delete<void>(this.apiServiceUrl+"/"+employeeId)
    .pipe(map((res:void)=>{
      return res;
    }))
  }
}
