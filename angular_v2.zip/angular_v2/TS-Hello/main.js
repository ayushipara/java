"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var point_1 = require("./point");
var point = new point_1.Point('sanjay');
point.LastName = 'Barais';
console.log(point.FirstName + ' ' + point.LastName);
