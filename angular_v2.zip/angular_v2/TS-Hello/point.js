"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Point = void 0;
var Point = /** @class */ (function () {
    function Point(firstName, lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
    Object.defineProperty(Point.prototype, "FirstName", {
        get: function () {
            return this.firstName;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Point.prototype, "LastName", {
        get: function () {
            return this.lastName;
        },
        set: function (lastName) {
            if (lastName.length > 5)
                this.lastName = lastName;
            else
                this.lastName = 'xyz';
        },
        enumerable: false,
        configurable: true
    });
    return Point;
}());
exports.Point = Point;
