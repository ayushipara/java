export class Point{

    constructor(private firstName:string, private lastName?:string){
    }

    get FirstName(){
        return this.firstName;
    }

    get LastName(){
        return this.lastName;
    }

    set LastName(lastName:string){
        if(lastName.length>5)
            this.lastName=lastName;
        else
            this.lastName='xyz';
    }

}