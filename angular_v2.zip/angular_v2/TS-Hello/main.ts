import { Point } from "./point";


let point = new Point('sanjay');
point.LastName = 'Barais'
console.log(point.FirstName +' '+ point.LastName);
