export const environment = {
  production: true,
  apiURL: 'fx.yahoo.com'
};
