import { Employee } from './employee-dashboard.model';
import { ApiService } from './../shared/api.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormControl,FormGroup } from '@angular/forms';

@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.scss']
})
export class EmployeeDashboardComponent implements OnInit {
  
  formValue !: FormGroup;
  employeeData !:any;
  showAdd !: boolean;
  showUpdate !: boolean;

  constructor(private formBuilder:FormBuilder,
    private apiService:ApiService) { }

  ngOnInit(): void {
    this.formValue = this.formBuilder.group({
      id: [''],  
      firstName : [''],
      lastName : [''],
      email:[''],
      mobile:[''],
      salary:['']
    })

    this.getAllEmployee();
  }

  postEmployeeDetail(){
    this.formValue.removeControl('id');
    this.apiService.postEmploye(this.formValue.value)
    .subscribe({
      next:(res)=>{
        console.log(res);
        alert("Employee added successfully")
        document.getElementById("cancel")?.click();
        this.formValue.setControl('id',new FormControl(''));
        this.clearData();
      },
      error:(e)=> {alert("Something went wrong")
                  console.log(e.console.error())      
    },
      complete: ()=> this.getAllEmployee()
    })
  }

  getAllEmployee(){
    this.apiService.getEmployee()
    .subscribe(res=>{
      this.employeeData = res;
    })
  }

  deleteEmployee(row:any){
    this.apiService.deleteEmploye(row.id)
    .subscribe({
      next : (res)=> {
        alert("Employee Removed")
        this.getAllEmployee();
      },
      complete : ()=>console.log("Data Deleted")
    }
    );
  }

  onEdit(row:any){
    this.showAdd = false;
    this.showUpdate = true;
    console.log(row.id);
    this.formValue.controls['id'].setValue(row.id);
    this.formValue.controls['firstName'].setValue(row.firstName);
    this.formValue.controls['lastName'].setValue(row.lastName);
    this.formValue.controls['email'].setValue(row.email);
    this.formValue.controls['mobile'].setValue(row.mobile);
    this.formValue.controls['salary'].setValue(row.salary);
  }

  updateEmployeeDetail(){
    let id = this.formValue.value.id;
    this.formValue.removeControl('id');
    this.apiService.updateEmploye(this.formValue.value,id)
    .subscribe({
      next : (res)=>{
        alert("Employee updated")
        document.getElementById("cancel")?.click();
        this.formValue.setControl('id',new FormControl(''));
        this.clearData();
      },
      error:(e)=> alert("Something went wrong"),
      complete: ()=> this.getAllEmployee()
    })
  }

  addNewEmployee(){
    this.clearData();
    this.showAdd = true;
    this.showUpdate = false;
  }

  clearData(){
    this.formValue.reset();
  }

}
 